using System;

namespace AIS.Models
{
    public class AuditEmployeeModel
    {        
        public int PPNO { get; set; }
        public int DEPARTMENTCODE { get; set; }
        public string DEPTARMENT { get; set; }
        public string EMPLOYEEFIRSTNAME { get; set; }
        public string EMPLOYEELASTNAME { get; set; }
        public int RANKCODE { get; set; }
        public string CURRENT_RANK { get; set; }     
        public int DESIGNATIONCODE { get; set; }
        public string FUN_DESIGNATION { get; set; }
        public string TYPE { get; set; }
    }
}
