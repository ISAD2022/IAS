using System;

namespace AIS.Models
{
    public class RiskGroupModel
    {        
        public int GR_ID { get; set; }
        public string DESCRIPTION { get; set; }
      
    }
}
