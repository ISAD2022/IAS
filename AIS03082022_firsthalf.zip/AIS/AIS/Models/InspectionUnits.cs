using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class InspectionUnitsModel
    {
        public int I_ID { get; set; }
        public string I_CODE { get; set; }
        public string UNIT_NAME { get; set; }
        public string DISCRIPTION { get; set; }
        public string STATUS { get; set; }

    }
}
