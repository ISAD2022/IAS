using System;

namespace AIS.Models
{
    public class ControlViolationsModel
    {
        public int ID { get; set; }        
        public string V_NAME { get; set; }
        public int MAX_NUMBER { get; set; }
        public string STATUS { get; set; }

    }
}
