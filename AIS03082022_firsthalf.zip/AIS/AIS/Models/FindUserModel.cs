using System;

namespace AIS.Models
{
    public class FindUserModel
    {
        
        public int PPNUMBER { get; set; }
        public int LOGINNAME { get; set; }
        public string EMAIL { get; set; }
        public int DIVISIONID { get; set; }
        public int DEPARTMENTID { get; set; }
        public int ZONEID { get; set; }
        public int BRANCHID { get; set; }
        public int GROUPID { get; set; }     
      
    }
}
