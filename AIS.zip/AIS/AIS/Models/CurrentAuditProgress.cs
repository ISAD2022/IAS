using System;
using System.ComponentModel.DataAnnotations.Schema;
namespace AIS.Models
{
    public class CurrentAuditProgress
    {
        public string CODE { get; set; }
        public string NAME { get; set; }
        public string AREA { get; set; }
        public int OBS_COUNT { get; set; }
    }
}
