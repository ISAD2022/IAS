using System;
using System.ComponentModel.DataAnnotations.Schema;
namespace AIS.Models
{
    public class CurrentActiveUsers
    {
        public string DEPARTMENT_NAME { get; set; }
        public string NAME { get; set; }
        public int PP_NUMBER { get; set; }
        public DateTime? LOGGED_IN_DATE { get; set; }
        public string SESSION_TIME { get; set; }
    }
}
