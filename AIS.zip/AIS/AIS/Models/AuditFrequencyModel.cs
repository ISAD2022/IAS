using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class AuditFrequencyModel
    {
        public int ID { get; set; }
        public int FREQUENCY_ID { get; set; }
        public string FREQUENCY_DISCRIPTION { get; set; }
        public string STATUS { get; set; }

    }
}
