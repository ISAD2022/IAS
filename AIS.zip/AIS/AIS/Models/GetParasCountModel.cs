using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class GetParasCountModel
    {        
        public int? count{ get; set; }
        
    }
}
