using System;

namespace AIS.Models
{
    public class AvatarNameDisplayModel
    {        
        public string PPNO { get; set; }
        public int Menu_Id { get; set; }
        public string Name { get; set; }
        
    }
}
