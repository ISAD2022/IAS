using System;

namespace AIS.Models
{
    public class FadOldParaReportModel
    {

        public int PERIOD { get; set; }
        public string ENTITY_NAME { get; set; }

        public string PROCESS { get; set; }
        public string SUB_PROCESS { get; set; }

        public string VIOLATION { get; set; }
        public string OBS_TEXT { get; set; }
        public string OBS_RISK { get; set; }
        public string OBS_STATUS { get; set; }


    }
}
