using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class GetOldParasForComplianceResponse
    {
        public string PROCESS_DES { get; set; }

        public string SUB_PROCESS_DES { get; set; }
        public int? CHECK_LIST_DETAIL_DES { get; set; }


    }
}
