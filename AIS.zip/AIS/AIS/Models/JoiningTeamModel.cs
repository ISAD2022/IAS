using System;
using System.Collections.Generic;

namespace AIS.Models
{
    public class JoiningTeamModel
    {        
       
        public int PP_NO { get; set; }
        public string EMP_NAME { get; set; }
        public string TEAM_NAME { get; set; }
        public string IS_TEAM_LEAD { get; set; }


    }
}
