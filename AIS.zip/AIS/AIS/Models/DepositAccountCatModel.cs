using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class DepositAccountCatModel
    {
        public string BRANCH_NAME { get; set; }
        public string ACCOUNTCATEGORY { get; set; }
        public int? ACCOUNTCATEGORYID { get; set; }
        public double AMOUNT { get; set; }
        public string ACCOCUNTSTATUS { get; set; }

    }
}
