using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class OldParasModelCAD
    {
        public int PARA_ID { get; set; }       
        public string AUDIT_PERIOD { get; set; }
        public string ENTITY_NAME { get; set; }
        public string GIST_OF_PARAS { get; set; }
        public int ENTITY_ID { get; set; }
        public string AUDITED_BY { get; set; }
        public string PARA_NO { get; set; }
        public string PARA_TEXT { get; set; }
        public string PARA_STATUS { get; set; }
        public int V_CAT_ID { get; set; }
        public int V_CAT_NATURE_ID { get; set; }
        public int RISK_ID { get; set; }
    }
}
