using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class LoanCasedocModel
    {
        public string TEAM_MEM_PPNO { get; set; }
        public string BRANCHCODE { get; set; }
        public string LOAN_APP_ID{ get; set; }
        public string CNIC { get; set; }
        public string LOAN_CASE_NO { get; set; }
        public string GLSUBCODE  { get; set; }
        public string CUSTOMERNAME { get; set; }
        public string LOAN_DISB_ID { get; set; }
        public string DOCUMENTS { get; set; }
        public string IMAGES { get; set; }

    }




}

