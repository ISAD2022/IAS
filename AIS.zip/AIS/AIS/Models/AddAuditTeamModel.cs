using System;
using System.ComponentModel.DataAnnotations.Schema;
namespace AIS.Models
{
    public class AddAuditTeamModel
    {
        public int ID { get; set; }
        public string T_CODE { get; set; }
        public string T_NAME { get; set; }
        public int PPNO { get; set; }
        public string NAME { get; set; }
        public string PLACEOFPOSTING { get; set; }       
        public string ISTEAMLEAD { get; set; }
        public string STATUS { get; set; }
    }
}
