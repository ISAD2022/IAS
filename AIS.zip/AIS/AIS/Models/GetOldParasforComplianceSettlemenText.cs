using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class GetOldParasforComplianceSettlemenText
    {
        public string PARATEXT { get; set; }
        public string PROCESSDES { get; set; }
        public string SUBPROCESSDES { get; set; }
        public string CHECKLISTDETAIL { get; set; }


    }
}
