using System;

namespace AIS.Models
{
    public class CriteriaIDComment
    {
        public int ID { get; set; }
        public string COMMENT { get; set; }
    }
}
