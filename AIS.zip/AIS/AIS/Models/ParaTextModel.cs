using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class ParaTextModel
    {        
        public int? MEMO_NO { get; set; }
        public string MEMO_TXT { get; set; }
        
    }
}
