using System;

namespace AIS.Models
{
    public class SubCheckListStatus
    {
        public int S_ID { get; set; }
        public int CD_ID { get; set; }
        public int OBS_ID { get; set; }
        public string Status { get; set; }
    }
}
