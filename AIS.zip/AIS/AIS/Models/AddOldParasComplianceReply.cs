using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class AddOldParasComplianceReply
    {
      
        public int? PPNO { get; set; }
        public int? PID { get; set; }
        public string REPLY { get; set; }
        


    }
}
