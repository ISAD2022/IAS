using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class AuditVoilationcatModel
    {
        public int ID { get; set; }
        public string V_NAME { get; set; }

        public int MAX_NUMBER { get; set; }

        public string STATUS { get; set; }

    }
}
